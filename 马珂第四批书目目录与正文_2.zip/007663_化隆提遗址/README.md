# 化隆提遗址

- 序号：7663
- 来源网址：https://kns.cnki.net/kcms2/article/abstract?v=u5lPRpBnolix8lH_AZpfFhI1j1hBdJn8erMDd_mYDM-7E_FoGgJ_twiug9JeB9BwET1G4rcyrjgjPDTy30074kOORZkLMSELhvbJmtu_UKFQ9jPizkrnELnZJiiQfrrQoQg0-g_A87E3JXeHacpSCAzt4fiOGdFy4Fv3uJbJl5znyt3Pkp48Hw==
- 爬取状态：是
- 出版社：未详
- 出版版别：未详
- 文件状态：已有正文文本，已纳入标准结构。

## 提交信息

- 编号：007663
- 题名：化隆提遗址
- 来源网址：https://kns.cnki.net/kcms2/article/abstract?v=u5lPRpBnolix8lH_AZpfFhI1j1hBdJn8erMDd_mYDM-7E_FoGgJ_twiug9JeB9BwET1G4rcyrjgjPDTy30074kOORZkLMSELhvbJmtu_UKFQ9jPizkrnELnZJiiQfrrQoQg0-g_A87E3JXeHacpSCAzt4fiOGdFy4Fv3uJbJl5znyt3Pkp48Hw==
- 来源：第三周第四组书目查找表及本文件夹源文件
- 作者或责任者：未详
- 出版社：未详
- 版别：未详
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
