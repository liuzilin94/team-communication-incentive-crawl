# 军机处相关公文

- 奏折人：张祥河
- 来源：用户提供正文
- 文献数量：四件（编号448—451）
- 卷数：一篇
- 正文文件：正文.txt
- 备注：保留各件编号、日期、上谕及朱批。

## 提交信息

- 编号：003688
- 题名：军机处相关公文
- 来源网址：http://www.junshilei.cn/n/dsrqw/book/base/13833669/8c8df157f08348bd87597c31a1322168/0ec308b4b5d05781d4a9771282394820.shtml?dm=-339430255&dxid=000015449267&tp=dsrquanwen&uf=1&userid=2003&aid=1128&bt=qw&pagetype=6&sKey=%E5%86%9B%E6%9C%BA%E5%A4%84%E5%BD%95%E5%89%AF%E5%A5%8F%E6%8A%98&sch=%E5%86%9B%E6%9C%BA%E5%A4%84%E5%BD%95%E5%89%AF%E5%A5%8F%E6%8A%98&searchtype=qw&sourceurl=43d26d1f384904422c3b78c07dc074f3ee866465eb801e9ae02205beb091265309be6624587199f26b0b22de804c317a999fec4ef642780dba391b1bb10c62fae2220610edee49160279d662d4c8180e1a119f18e1424681519ad23b863ab38e8a0cbd49692e97e22c56640ac74958a43b133a39f7768861b75eb259dd2cbc5e&template=dsrquanwen&zjid=000015449267_457
- 来源：用户提供正文
- 作者或责任者：张祥河
- 出版社：未详
- 版别：未详
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
