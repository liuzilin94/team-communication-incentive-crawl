# 题为审理颍上县回民白獐因劝阻讹索客钱争闹伤毙王栋一案依律拟绞监候请旨事

本目录为序号 5870《题为审理颍上县回民白獐因劝阻讹索客钱争闹伤毙王栋一案依律拟绞监候请旨事》的标准整理成果。

正文依据用户提供文本整理，保留原文内容，仅统一段落与文件命名。正文收录于 `正文.txt`。

## 提交信息

- 编号：005870
- 题名：题为审理颍上县回民白獐因劝阻讹索客钱争闹伤毙王栋一案依律拟绞监候请旨事
- 来源网址：https://qingarchives.npm.edu.tw/index.php?act=Archive%2Fsearch%2F1-20%2FeyJhY2NudW0iOiIiLCJzZWFyY2giOlt7ImZpZWxkIjoiX2FsbCIsInZhbHVlIjoi6aGM54K65a%2Bp55CG5r2B5LiK57ij5Zue5rCR55m9542Q5Zug5Yu46Zi76Kib57Si5a6i6Yyi54it6ayn5YK35paD546L5qOf5LiA5qGI5L6d5b6L5pOs57We55uj5YCZ6KuL5peo5LqLIn1dLCJkdGZpbHRlciI6e30sInBxZmlsdGVyIjpbXSwic29ydGJ5Ijp7Im1vZGUiOiJkYXRlX2FzYyJ9LCJmYWNldHNieSI6InBxX2R5bmFzdHkifQ%3D%3D
- 来源：用户提供正文
- 作者或责任者：未详
- 出版社：不适用（清代司法档案）
- 版别：国立故宫博物院清代档案检索系统数字化影像候选本
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
