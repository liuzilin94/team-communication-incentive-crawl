# 万福纹碧玉圆盒

- 序号：11253
- 来源网址：https://digicol.dpm.org.cn/cultural/detail?f_link_type=f_linkinlinenote&flow_extra=eyJpbmxpbmVfZGlzcGxheV9wb3NpdGlvbiI6MCwiZG9jX3Bvc2l0aW9uIjowLCJkb2NfaWQiOiIxNjUxNjA0MmU5NTVhNzBjLWJkNDdiMjdkYjJmNTg1NzMifQ%3D%3D&id=5cc1a14365974123ade10bad62211e7a
- 爬取状态：是
- 出版社：未详
- 出版版别：未详
- 文件状态：相关资料已整理归档。
- 保留源文件：《万福纹碧玉圆盒》.png

## 提交信息

- 编号：011253
- 题名：万福纹碧玉圆盒
- 来源网址：https://digicol.dpm.org.cn/cultural/detail?f_link_type=f_linkinlinenote&flow_extra=eyJpbmxpbmVfZGlzcGxheV9wb3NpdGlvbiI6MCwiZG9jX3Bvc2l0aW9uIjowLCJkb2NfaWQiOiIxNjUxNjA0MmU5NTVhNzBjLWJkNDdiMjdkYjJmNTg1NzMifQ%3D%3D&id=5cc1a14365974123ade10bad62211e7a
- 来源：第三周第四组书目查找表及本文件夹源文件
- 作者或责任者：未详
- 出版社：未详
- 版别：未详
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：无；待核
- 待复核：正文与原件的完整性及准确性。
