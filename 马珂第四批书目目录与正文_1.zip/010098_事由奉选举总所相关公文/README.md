# 事由奉选举总所相关公文

本目录为序号 10098《事由奉选举总所相关公文》的标准整理成果。

正文依据用户提供文本整理，保留原文内容，仅统一段落与文件命名。正文收录于 `正文.txt`。

## 提交信息

- 编号：010098
- 题名：事由奉选举总所相关公文
- 来源网址：https://www.cnbksy.com/v2/search/detail?Id=d80114d24c59331ce62e28184669cda9&activeId=6ac8b61e7ab82d28482debed&LiteratureCategory=7&LiteratureCategoryPieceTypeId=7&ngTitle=(%E9%80%9A%E5%91%8A%EF%BC%9A%E5%9B%BD%E6%B0%91%E5%A4%A7%E4%BC%9A%E5%AE%89%E5%BE%BD%E7%9C%81%E4%BB%A3%E8%A1%A8%E9%80%89%E4%B8%BE%E7%9B%91%E7%9D%A3%E9%80%9A%E5%91%8A%EF%BC%9A%E5%9B%BD%E6%B0%91%E5%A4%A7%E4%BC%9A%E5%AE%89%E5%BE%BD%E7%9C%81%E4%BB%A3%E8%A1%A8%E9%80%89%E4%B8%BE%E4%BA%8B%E5%8A%A1%E6%89%80%E9%80%9A%E5%91%8A%EF%BC%9A%E7%AC%AC%E4%B8%80%E5%8F%B7%EF%BC%88%E4%B8%AD%E5%8D%8E%E6%B0%91%E5%9B%BD%E4%BA%8C%E5%8D%81%E5%85%AD%E5%B9%B4%E4%BA%94%E6%9C%88%E4%BA%8C%E5%8D%81%E4%B8%89%E6%97%A5%EF%BC%89%EF%BC%9A%E5%A5%89%E5%9B%BD%E6%B0%91%E5%A4%A7%E4%BC%9A%E4%BB%A3%E8%A1%A8%E9%80%89%E4%B8%BE%E6%80%BB%E4%BA%8B%E5%8A%A1%E6%89%80%E4%BB%A4%E4%BB%A5%E8%BD%AC%E5%A5%89%E5%9B%BD%E5%BA%9C%E4%BB%A4%E6%B4%BE%E9%AD%8F%E9%89%B4%E4%B8%BA%E5%9B%BD%E6%B0%91%E5%A4%A7%E4%BC%9A%E5%AE%89%E5%BE%BD%E7%9C%81%E4%BB%A3%E8%A1%A8%E9%80%89%E4%B8%BE%E6%80%BB%E7%9B%91%E7%9D%A3%E9%81%B5%E5%8D%B3%E6%8E%A5%E4%BB%BB%E8%A7%86%E4%BA%8B%E7%94%B1)&il8nKey=Component_Button_Search&il8nKey1=Navigation_PieceDetailSearchResult
- 来源：用户提供正文
- 作者或责任者：国民大会安徽省代表选举总监督魏鑑
- 出版社：未详
- 版别：未详
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
