# 学务

## 转存说明

- 序号：10354
- 题名：学务
- 成文时间：光绪二十九年十一月二十六日（1904年1月13日）
- 文献类型：学务章程
- 正文来源：用户提供的《学务.txt》
- 整理状态：已完成

## 文件说明

正文按照原有条目结构，以单一 `正文.txt` 保存。文本采用 UTF-8（无 BOM）编码和 LF 换行。

## 提交信息

- 编号：010354
- 题名：学务
- 来源网址：http://www.zhengzhifl.cn/n/dsrqw/book/base/12621706/369558fec23c4278bd362fc759378402/e136cdece1f183af8a07948d284fc18d.shtml?dm=-1805745327&dxid=000006920723&tp=dsrquanwen&uf=1&userid=2003&aid=1128&bt=qw&pagetype=6&sKey=%E3%80%8A%E5%A5%8F%E5%AE%9A%E5%AD%A6%E5%8A%A1%E7%BA%B2%E8%A6%81%E3%80%8B&sch=%E5%A5%8F%E5%AE%9A%E5%AD%A6%E5%8A%A1%E7%BA%B2%E8%A6%81&searchtype=qw&sourceurl=43d26d1f384904422c3b78c07dc074f3ee866465eb801e9ae02205beb091265309be6624587199f26b0b22de804c317a999fec4ef642780dba391b1bb10c62faf8a9f24ac1319bc4ffc33101ae15e3c736248a5aacbcbc8ae0ef4d59b0bfd33405da57003deda09cf31910b48b49c4d2c4f7ad438c904f2f1d2190950ef9b9dd&template=dsrquanwen&zjid=000006920723_61
- 来源：用户提供的《学务.txt》
- 作者或责任者：未详
- 出版社：未详
- 版别：未详
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
