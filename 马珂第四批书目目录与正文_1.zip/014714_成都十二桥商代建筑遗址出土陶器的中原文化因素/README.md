# 成都十二桥商代建筑遗址出土陶器的中原文化因素

## 转存说明

- 序号：14714
- 题名：成都十二桥商代建筑遗址出土陶器的中原文化因素
- 依据文献：《成都十二桥商代建筑遗址第一期发掘简报》
- 原文作者：李昭和、翁善良、张肖马等
- 刊载：《文物》1987年第12期
- 正文来源：用户提供文本
- 整理状态：已完成

## 文件说明

本篇正文以单一 `正文.txt` 保存，采用 UTF-8（无 BOM）编码和 LF 换行。

## 提交信息

- 编号：014714
- 题名：成都十二桥商代建筑遗址出土陶器的中原文化因素
- 来源网址：https://kns.cnki.net/kcms2/article/abstract?v=xiNUFhx2xxYsJyRrp1iEshRYQPB0KATaGStiM4U4Yk2oL7bz-hTd2TjzpFkxR61Hr5hq9yTWHa-bYqoSmkcQDaUpgYar_4OaGmkw91K1poCKcN5WqevxGBlQA2vf8WFc7077k9VvbGvHNNw4rdpreG8eM-QVWhASVTHD6AGaEABkoGoLWjzEgQ==
- 来源：用户提供文本
- 作者或责任者：据李昭和、翁善良、张肖马等文整理
- 出版社：未详
- 版别：未详
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
