# 修扎都水渠碑记

本目录按标准书目转存结构整理。

- 序号：7791
- 状态：已整理

## 提交信息

- 编号：007791
- 题名：修扎都水渠碑记
- 来源网址：https://mooc1.chaoxing.com/mooc-ans/ztnodedetailcontroller/visitnodedetail?_fromV2_=&_from_=&courseId=84717027&knowledgeId=84717091&rtag=
- 来源：mooc1.chaoxing.com
- 作者或责任者：未详
- 出版社：未详
- 版别：未详
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
