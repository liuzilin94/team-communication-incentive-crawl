# 段承钧经商纪闻

- 书名：段承钧经商纪闻
- 来源：表格网址及源文件夹
- 当前状态：已整理
- 文件说明：正文及相关资料已整理归档。

## 提交信息

- 编号：018555
- 题名：段承钧经商纪闻
- 来源网址：https://img.sslibrary.com/n/slib/book/slib/10208673/b82486da79324e52a0b7df9dc07a02c6/81d1f510e970327540d651d2a3012972.shtml?dxbaoku=true&moocbaoku=false&deptid=1128&ext=%7B%22from%22%3A%22sslibrary%22%7D&fav=https%3A%2F%2Fwww.sslibrary.com%2Freader%2Fpdg%2Fdxpdgreader%3Fxjbk%3D47%26d%3Df0e8433082bc66ae31a27d75fa302258%26enc%3D6cf67d64c3a3f1b010de3276ae408be1%26ssid%3D10208673%26did%3D1128&fenlei=110308&logintype=2&uid=343443907&username=star_1128&view=-1&refinfo=
- 来源：源文件夹及表格网址
- 作者或责任者：未详
- 出版社：未详
- 版别：未详
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
