# 清朝掌故汇编内编

## 转存说明

- 序号：15354
- 纂者：[清]张寿锒
- 来源：识典古籍“清朝掌故汇编内编”全文阅读页
- 来源网址：https://www.shidianguji.com/book/CADAL02027655/chapter/1laegab1o6s6g?page_from=reading_midpage
- 收录范围：网页卷首、目录、卷之首卷，以及卷一至卷六十
- 文件状态：全文已提取并按卷整理

## 整理规则

- 仅提取网页 `article` 正文，未收录站点导航、登录按钮、下载提示、词频统计和“下一篇”等页面元素。
- 网页“卷首”“目录”“卷之首卷”合并保存为 `卷首.txt`。
- 正文依次保存为 `卷一.txt` 至 `卷六十.txt`，不合并卷次。
- 各文件采用 UTF-8（无 BOM）和 LF 换行。
- 网页正文属于平台整理文本，异体字、缺字符号及识别结果按网页原貌保留，未擅自改写。

## 提交信息

- 编号：015354
- 题名：清朝掌故汇编内编
- 来源网址：https://www.shidianguji.com/book/CADAL02027655/chapter/1laegab1o6s6g?page_from=reading_midpage
- 来源：识典古籍全文阅读页
- 作者或责任者：[清]张寿锒 纂
- 出版社：未详
- 版别：未详
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：卷一.txt, 卷七.txt, 卷三.txt, 卷三十.txt, 卷三十一.txt, 卷三十七.txt, 卷三十三.txt, 卷三十九.txt, 卷三十二.txt, 卷三十五.txt, 卷三十八.txt, 卷三十六.txt, 卷三十四.txt, 卷九.txt, 卷二.txt, 卷二十.txt, 卷二十一.txt, 卷二十七.txt, 卷二十三.txt, 卷二十九.txt, 卷二十二.txt, 卷二十五.txt, 卷二十八.txt, 卷二十六.txt, 卷二十四.txt, 卷五.txt, 卷五十.txt, 卷五十一.txt, 卷五十七.txt, 卷五十三.txt, 卷五十九.txt, 卷五十二.txt, 卷五十五.txt, 卷五十八.txt, 卷五十六.txt, 卷五十四.txt, 卷八.txt, 卷六.txt, 卷六十.txt, 卷十.txt, 卷十一.txt, 卷十七.txt, 卷十三.txt, 卷十九.txt, 卷十二.txt, 卷十五.txt, 卷十八.txt, 卷十六.txt, 卷十四.txt, 卷四.txt, 卷四十.txt, 卷四十一.txt, 卷四十七.txt, 卷四十三.txt, 卷四十九.txt, 卷四十二.txt, 卷四十五.txt, 卷四十八.txt, 卷四十六.txt, 卷四十四.txt, 卷首.txt
- 待复核：正文与原件的完整性及准确性。
