# 唐故殿中侍御史淄州长史知军州事崔府君墓志铭并序

- 撰者：崔嗣之
- 来源：用户提供的拓片释读正文
- 卷数：一篇
- 正文文件：正文.txt
- 备注：石面存在残泐，阙字均以“□”标出。

## 提交信息

- 编号：013817
- 题名：唐故殿中侍御史淄州长史知军州事崔府君墓志铭并序
- 来源网址：http://www.jingjilei.cn/n/dsrqw/book/base/11423846/c9ed57d4fc964bc89a11009201b4420a/c5b3e254e09a294e88d7668738968511.shtml?dm=-845579977&dxid=000005757748&tp=dsrquanwen&uf=1&userid=2003&aid=1128&bt=qw&pagetype=6&sKey=%E3%80%8A%E5%94%90%E6%95%85%E6%AE%BF%E4%B8%AD%E4%BE%8D%E5%BE%A1%E5%8F%B2%E6%B7%84%E5%B7%9E%E9%95%BF%E5%8F%B2%E7%9F%A5%E5%86%9B%E5%B7%9E%E4%BA%8B%E5%B4%94%E5%BA%9C%E5%90%9B%E5%A2%93%E5%BF%97%E9%93%AD%E5%B9%B6%E5%BA%8F%E3%80%8B&sch=...%E5%92%8C%E9%97%B4%E5%B9%BF%E6%96%87%E9%A6%86%E8%BF%9B%E5%A3%AB%E5%94%90%E6%95%85%E6%AE%BF%E4%B8%AD.&searchtype=qw&sourceurl=43d26d1f384904422c3b78c07dc074f3ee866465eb801e9ae02205beb091265309be6624587199f26b0b22de804c317a999fec4ef642780dba391b1bb10c62fa9b1450010456acbb2394607cc00d7465c3600c4cd7ef6946b233767caed5ff66a84c96c96c8bf482b689301f27ed5b3a9f14a95d722cb492596d3be219a5c620&template=dsrquanwen&zjid=000005757748_1226
- 来源：用户提供的拓片释读正文
- 作者或责任者：崔嗣之
- 出版社：未详
- 版别：未详
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
