# 冀宁监郡朝列公祷雨感应颂

- 撰文：张修本
- 书丹：郭老亨
- 篆额：相哥
- 立石时间：至正八年八月二十三日
- 来源：用户提供正文
- 卷数：一篇
- 正文文件：正文.txt

## 提交信息

- 编号：012664
- 题名：冀宁监郡朝列公祷雨感应颂
- 来源网址：http://www.jingjilei.cn/n/dsrqw/book/base/13868087/417f927c99cd4513bf25a7b7b3aa8599/89d0956bcec351a24f9bedab82e0ce37.shtml?dm=-845579977&dxid=000030123865&tp=dsrquanwen&uf=1&userid=2003&aid=1128&bt=qw&pagetype=6&sKey=%E5%86%80%E5%AE%81%E7%9B%91%E9%83%A1%E6%9C%9D%E5%88%97%E5%85%AC%E7%A5%B7%E9%9B%A8%E6%84%9F%E5%BA%94%E9%A2%82&sch=%E5%86%80%E5%AE%81%E7%9B%91%E9%83%A1%E6%9C%9D%E5%88%97%E5%85%AC%E7%A5%B7%E9%9B%A8%E6%84%9F%E5%BA%94%E9%A2%82%EF%BC%88%E5%85%83%E8%87%B3&searchtype=qw&sourceurl=43d26d1f384904422c3b78c07dc074f3ee866465eb801e9ae02205beb091265309be6624587199f26b0b22de804c317a999fec4ef642780dba391b1bb10c62fa8be4767d7aa1043e9972c8499007ee68a2a58c6a1c8f3ed197d2523b4ce986a7ae7fb281258eab3341de5122393340e269ce3ca642d95e009d5dd703b49bd020&template=dsrquanwen&zjid=000030123865_2
- 来源：用户提供正文
- 作者或责任者：张修本撰，郭老亨书，相哥篆
- 出版社：未详
- 版别：未详
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
