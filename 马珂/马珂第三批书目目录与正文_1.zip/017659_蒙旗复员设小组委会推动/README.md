# 蒙旗复员设小组委会推动

- 书名：蒙旗复员设小组委会推动
- 来源：表格网址及源文件夹
- 当前状态：已完成（1卷 / 1,708字）
- 文件说明：正文及相关资料已整理归档。

## 提交信息

- 编号：017659
- 题名：蒙旗复员设小组委会推动
- 来源网址：https://www.cnbksy.com/v2/search/detail?Id=e5d1b4052b0dee4bef4466f97f7f002a24959713ccde817e1539750aef71f108&activeId=6aaa8ff24aa2c2293a6604ee&LiteratureCategory=3&LiteratureCategoryPieceTypeId=12&ngTitle=(%E8%92%99%E6%97%97%E5%A4%8D%E5%91%98)&il8nKey=Component_Button_Search&il8nKey1=Navigation_PieceDetailSearchResult
- 来源：源文件夹及表格网址
- 作者或责任者：未详
- 出版社：无
- 版别：无
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
