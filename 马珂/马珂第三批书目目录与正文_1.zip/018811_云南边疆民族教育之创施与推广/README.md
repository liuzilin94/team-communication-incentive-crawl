# 云南边疆民族教育之创施与推广

- 书名：云南边疆民族教育之创施与推广
- 来源：表格网址及源文件夹
- 当前状态：已整理
- 文件说明：正文及相关资料已整理归档。

## 提交信息

- 编号：018811
- 题名：云南边疆民族教育之创施与推广
- 来源网址：https://www.cnbksy.com/v2/search/detail?Id=36b3887773dfc7652b8c03520b94683c&activeId=6aaa7b5c007c333f0444c1a5&LiteratureCategory=7&LiteratureCategoryPieceTypeId=7&ngTitle=(%E4%BA%91%E5%8D%97%E8%BE%B9%E7%96%86%E6%B0%91%E6%97%8F%E6%95%99%E8%82%B2%E4%B9%8B%E5%88%9B%E6%96%BD%E4%B8%8E%E6%8E%A8%E5%B9%BF)&il8nKey=Component_Button_Search&il8nKey1=Navigation_PieceDetailSearchResult
- 来源：源文件夹及表格网址
- 作者或责任者：未详
- 出版社：《中华邮工》
- 版别：1935年[ 第1卷 第5/6期 ]
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
