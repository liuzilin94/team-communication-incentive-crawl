# 智明造像题记

- 书名：智明造像题记
- 来源：表格网址及源文件夹
- 当前状态：是
- 文件说明：正文及相关资料已整理归档。

## 提交信息

- 编号：013689
- 题名：智明造像题记
- 来源网址：http://arts.fgs.org.tw/tw/keyword_search_detail.php?arg=SkVCCL8DzwdsKb1rN1nS80tYqB%2F8eUYHwTCYhE0g5RjhG3yXQlusP03LAw
- 来源：源文件夹及表格网址
- 作者或责任者：未详
- 出版社：未详
- 版别：未详
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
