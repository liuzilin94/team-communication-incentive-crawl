# 明邢镔及妻郑氏合葬墓志

- 题名：明诰赠光禄大夫、太子太保、兵部尚书兼都察院右副都御史西冈邢公暨配累封一品太夫人郑氏合葬墓志铭
- 撰文：王锡爵
- 篆盖：蹇达
- 书丹：万世德
- 来源：用户提供原文
- 卷数：一篇
- 正文文件：正文.txt

## 提交信息

- 编号：014073
- 题名：明邢镔及妻郑氏合葬墓志
- 来源网址：https://kns.cnki.net/kcms2/article/abstract?v=u5lPRpBnoljEXRZ1n2Rt5MWkph7icB0yGaGO3WwSvm1m3ldpLnEzQ92yRdgdvWo5YJyh4-KekYS9kZxEl0hw26SSp09MrjvuB_mvEhHXf2-f0hokrx2jqXCwpf1exeOikGdh2e1TO71tuNEI-TmDLQyNfYMYnJrXOegyR1jX0ekWSO_b3FgPQA==
- 来源：用户提供原文
- 作者或责任者：王锡爵撰文，蹇达篆盖，万世德书丹
- 出版社：未详
- 版别：未详
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
