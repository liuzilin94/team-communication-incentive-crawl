# 6126一九三五年十一月十四日  阴

本书目文件夹转存说明。

## 提交信息

- 编号：006126
- 题名：一九三五年十一月十四日  阴
- 来源网址：https://www.chinawriter.com.cn/n1/2021/0908/c440988-32221783.html?f_link_type=f_linkinlinenote&flow_extra=eyJkb2NfcG9zaXRpb24iOjAsImRvY19pZCI6IjAxMjk0MDhmNWI2OThjZWEtZWI4OWQyNDc4NzJmMTg5NyIsImlubGluZV9kaXNwbGF5X3Bvc2l0aW9uIjowfQ%3D%3D
- 来源：待核
- 作者或责任者：未详
- 出版社：上海容光书局
- 版别：1935年初版
- 当前内容范围：现存 TXT 文件所含内容；完整性待核
- 正文 TXT 文件：正文.txt
- 待复核：正文与原件的完整性及准确性。
